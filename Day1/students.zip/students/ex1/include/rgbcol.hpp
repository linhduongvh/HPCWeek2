/*
 * rgbcol.hpp
 *
 *  Created on: 16 févr. 2016
 *      Author: aliquando
 */

#ifndef RGBCOL_HPP_
#define RGBCOL_HPP_

typedef unsigned char uchar;

struct pixelcolor {
		uchar r, g, b;
	};



#endif /* RGBCOL_HPP_ */
